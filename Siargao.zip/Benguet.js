function toggleReadMore() {
    var culture = document.querySelector('.culture');
    var readmore  = document.querySelector('.readmore');
    
    if (culture.style.display === 'none') {
      culture.style.display = 'block';
      readmore .innerHTML = 'Read Less';
    } else {
      culture.style.display = 'none';
      readmore .innerHTML = 'Read More';
    }
  }

function toggleReadMore1() {
    var culture1 = document.querySelector('.culture1');
    var readmore1 = document.querySelector('.readmore1');
    
    if (culture1.style.display === 'none') {
      culture1.style.display = 'block';
      readmore1 .innerHTML = 'Read Less';
    } else {
      culture1.style.display = 'none';
      readmore1 .innerHTML = 'Read More';
    }
  }

function toggleReadMore2() {
    var culture2 = document.querySelector('.culture2');
    var readmore2 = document.querySelector('.readmore2');
    
    if (culture2.style.display === 'none') {
      culture2.style.display = 'block';
      readmore2 .innerHTML = 'Read Less';
    } else {
      culture2.style.display = 'none';
      readmore2 .innerHTML = 'Read More';
    }
  }

  function toggleReadMore3() {
    var culture3 = document.querySelector('.culture3');
    var readmore3 = document.querySelector('.readmore3');
    
    if (culture3.style.display === 'none') {
      culture3.style.display = 'block';
      readmore3 .innerHTML = 'Read Less';
    } else {
      culture3.style.display = 'none';
      readmore3 .innerHTML = 'Read More';
    }
  }

  function toggleReadMore4() {
    var culture4 = document.querySelector('.culture4');
    var readmore4 = document.querySelector('.readmore4');
    
    if (culture4.style.display === 'none') {
      culture4.style.display = 'block';
      readmore4 .innerHTML = 'Read Less';
    } else {
      culture4.style.display = 'none';
      readmore4 .innerHTML = 'Read More';
    }
  }
  